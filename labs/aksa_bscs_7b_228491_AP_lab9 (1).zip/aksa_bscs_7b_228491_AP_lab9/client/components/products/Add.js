import React, {Component} from 'react';
import M from 'materialize-css';
class Add extends Component {
  constructor()
  {
    super()
    this.state ={
      products:[],
      isHidden:false,
    }
    this.buttonValue="Add Items"
    this.handleChange = this.handleChange.bind(this);
  }
  handleChange(){
    this.setState({
      isHidden: !(this.state.isHidden)
    })
    if (this.buttonValue=="Add Items")
    {
      this.buttonValue = "Cancel";
    }
    else
    {
      this.buttonValue="Add Items"
    }
  }
  componentDidMount()
  {
    M.AutoInit();
  }
  render()
  {
    return (
    <div>
      <button className="btn waves-effect waves-light" onClick={()=>this.handleChange()}>{this.buttonValue}</button>
      {this.state.isHidden && <div><h1>Add product here</h1>
      <div className="row">
      <form action='/api/products/create' method="post" className="col s12">
        <div className="row">
        <div className="col s6">
        <label for="name">Product Name</label>
        <input type="text" name="name"  placeholder="Enter product name here" />
        </div>
        <div className="col s6">
        <label for="category">Product Category</label>
        <input type="text" name="category" placeholder="Enter product id here" />
        </div>
        </div>
        <div className="row">
        <div className="col s6">
        <label for="image">Image Url</label>
        <input type="text" name="image" placeholder="Enter Image Url" />
        </div>
        <div className="col s6">
        <label for="price">Price</label>
        <input type="number" name="price" placeholder="Enter price of the product" step="0.01" min="0" />
        </div>
        </div>
        <div className="row">
        <div className="col s12">
        <label for="desc">Description</label>
       <textarea name="desc" className="materialize-textarea"></textarea><br /><br />
        </div>
        </div>
        <button type="submit" className="btn waves-effect waves-light">Done</button>
       </form>< /div>
       < /div>}
      
    </div>
  );
  }
  
}

export default Add;