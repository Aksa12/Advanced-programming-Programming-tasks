import React, {Component} from 'react';
import M from 'materialize-css';
//import 'materialize-css/dist/css/materialize.min.css';
//import 'react-materialize';

const axios = require('axios').default;
class Product extends Component {
  constructor()
  {
    super()
    this.state ={
      products:[],
      cart:[],
      price:0
    }
    this.handleChangeA = this.handleChangeA.bind(this);
     this.handleChangeD = this.handleChangeD.bind(this);
     this.handleDelete = this.handleDelete.bind(this);
     this.handleCart = this.handleCart.bind(this);
     this.handleDeleteItem = this.handleDeleteItem.bind(this);
  }
  handleDeleteItem(name)
  {
    console.log("delete"+name)
     axios.get('/api/products/cart/delete/'+name).then(response=>
        this.setState({products:response.data[0], cart:response.data[1], price:response.data[2].price},()=>console.log("products fetched", response.data))
      )
  }
  handleCart(name)
  {
    console.log(name)
    axios.get('/api/products/cart/'+name).then(response=>
        this.setState({products:response.data[0], cart:response.data[1], price:response.data[2].price},()=>console.log("products fetched", response.data))
      )
  }
  handleChangeA(event)
  {
    axios.get('/api/products/asc').then(response=>
        this.setState({products:response.data[0], cart:response.data[1], price:response.data[2].price},()=>console.log("products fetched", response.data))
      )
  }
  handleDelete(name)
  {
    console.log(name)
    axios.get('/api/products/delete/'+name).then(response=>
        this.setState({products:response.data[0], cart:response.data[1], price:response.data[2].price},()=>console.log("products fetched", response.data))
      )
  }
  handleChangeD(event)
  {
    axios.get('/api/products/dsc').then(response=>
         this.setState({products:response.data[0], cart:response.data[1], price:response.data[2].price},()=>console.log("products fetched", response.data))
      )

  }
  componentDidMount()
  {
    M.AutoInit()
    axios.get('/api/products').then(response=>
         this.setState({products:response.data[0], cart:response.data[1], price:response.data[2].price},()=>console.log("products fetched", response.data))
      )
  }
  render()
  {
    return (
    <div>
      <h1>Products</h1>
      <button className="btn waves-effect waves-light" onClick={this.handleChangeA}>Ascending Order
      </button><br /><br />
      <button className="btn waves-effect waves-light" onClick={this.handleChangeD}>Descending Order
      </button>
      <div>
      <div className="col s4 m4">
      <h2 className="header">Your Cart</h2>
      <div className="card horizontal">
        <div className="card-image">
          <img src="https://lorempixel.com/100/190/nature/6" />
        </div>
        <div className="card-stacked">
         { this.state.cart.map(item=>
          <div>
          <div className="card-content">
          Name: {item.name} Quantity : {item.quantity} <a class="btn-floating waves-effect waves-light red" onClick={()=>this.handleDeleteItem(item.name)}><i class="material-icons">delete</i></a>
          </div>
         </div>
          )}
          <div className="card-content">
          Total Price : {this.state.price}
          </div> 
        </div>
      </div>
    </div>
      
      </div>
        <div className="row">
        {
          this.state.products.map(product => 
      <div className="col s12 m4">
        <div className="card">
          <div className="card-image">
            <img src={product.image} height="200px" />
            <span className="card-title blue-text text-darken-2">{product.name}</span>
            <span style={{marginLeft: "250px"}}>Delete item</span><a class="btn-floating halfway-fab waves-effect waves-light red" onClick={()=>this.handleDelete(product.name)}><i class="material-icons">delete</i></a>
          </div>
          <div className="card-content">
            {product.desc}
          </div>
          <div className="card-action">
            Add to cart<a style={{marginLeft: "20px"}} class="btn-floating  waves-effect waves-light red" onClick={()=>this.handleCart(product.name)}><i class="material-icons">add</i></a>
          </div>
          <div className="card-action">
            Price ${product.price}
          </div>
        </div>
      </div>
 )
        }
     </div></div>
  );
  }
  
}

export default Product;

