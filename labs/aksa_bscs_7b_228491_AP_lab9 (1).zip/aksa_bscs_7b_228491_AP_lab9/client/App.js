import React, {Component} from 'react';
import './App.css';
import Product from './components/products/Product';
import Add from './components/products/Add'

class App extends Component {
  constructor()
  {
    super()
  }
  render()
  {
    return (
    <div className="App">
      <Product />
      <Add />
    </div>
  );
  }
  
}

export default App;
