const path = require('path');
const express = require('express');
const app = express();

require("./models/db");
var Product = require('./models/product.model')

var bodyParser = require("body-parser")
var multer = require('multer')
var upload = multer()
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}))
app.use(upload.array())
var data;
var fs = require('fs');
//<tr key={product._id}><td>{product.name}</td><td>{product.category}</td><td>{product.desc}</td><td>{product.price}</td><td><img height="100px" width="100px" src={product.image} /></td></tr>)
var cart = [];
var price = 0;
var productitems;
Product.find(function(err, resp)
			{
				if (err) throw err;
				console.log(resp)
				console.log(resp.length)
				productitems = resp
				console.log(productitems)
			})
const cors = require('cors');
app.use(cors())
app.get('/api/products', (req, res)=>{
	Product.find(function(err, response)
			{
				if (err) throw err;
				console.log(response)
				console.log(response.length)
				productitems = response
				data = [productitems, cart, {price:price}]
				res.send(data)
				console.log(data)
			})

})
app.get('/api/products/cart/:name',(req, res)=>
{
	var pname= req.params.name;
	var quantity=0;
	console.log(pname);
	Product.findOne({name:pname},function(err, response)
	{
		if (err) throw err;
		console.log(response)
		console.log(response.length)
		price += response.price;
		console.log(price)
		var getitem = cart.find((item, i)=>{
		if (item.name === pname)
		{
			quantity =cart[i].quantity +1;
			cart[i] = {name:pname, quantity:quantity};
		}
	})
	if (quantity == 0)
	{
		quantity +=1
		var it = {
			name: pname,
			quantity:quantity,
		}
		cart.push(it)	
	}
	data = [productitems, cart, {price:price}]
	res.send(data)
	})
	

	
})

app.get('/api/products/cart/delete/:name',(req, res)=>
{
	var pname= req.params.name;
	console.log(pname);
	var itemp;
	Product.findOne({name:pname}, function(err, response)
	{
		if (err) throw err;
		console.log(response)
		console.log(response.length)
		itemp = response.price;
		price = price - itemp;
		console.log(price)
		var newarray;
		var index;
	var getitem = cart.find((item, i)=>{
		if (item.name === pname)
		{
			console.log(item.name)
			if (item.quantity == 1 )
			{
             index=i;
              cart.splice(index, 1)
			}
			else
			{
				var quantity =cart[i].quantity -1;
			    cart[i] = {name:pname, quantity:quantity};
			}
			
		}
		})
		data = [productitems, cart, {price:price}]
		res.send(data)
	})
	
})

app.get('/api/products/delete/:name', (req, res)=>{
	var pname = req.params.name;
			console.log(pname)
			Product.deleteOne({name:pname}, function(err, response)
			{
				if (err) throw err;
				console.log(response.deletedCount)
				res.redirect("/api/products")
				
				
			})
})
app.get('/api/products/asc', (req, res)=>{
	Product.find().sort({price:1}).exec(function(err, response)
			{
				if (err) throw err;
				console.log(response)
				console.log(response.length)
				productitems = response
				data = [productitems, cart, {price:price}]
				res.send(data)
				console.log(data)
			})

})
app.get('/api/products/dsc', (req, res)=>{
	Product.find().sort({price:-1}).exec(function(err, response)
			{
				if (err) throw err;
				console.log(response)
				console.log(response.length)
				productitems = response
				data = [productitems, cart, {price:price}]
				res.send(data)
				console.log(data)
			})

})
app.post('/api/products/create', function(req, res){
	console.log("helloo");
	var name = req.body.name;
	var category = req.body.category;
	var image= req.body.image;
	var desc = req.body.desc
	var price= parseFloat(req.body.price);
	var newProduct = {
		name:name,
		category:category,
		price:price,
		image:image,
		desc:desc
	}
	var product = new Product(newProduct)
	product.save(function(err, Product)
	{
		if (err) throw err;
		console.log("product saved in database")
		console.log(Product)
		})
	console.log("added")
	res.redirect('/api/products')
})
const port =  5000;
app.listen(port, ()=>console.log('server started on ${port}'))