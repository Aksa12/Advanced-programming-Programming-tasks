export class Photo {
  _id: string;
  filePath: string;
  fileSize: string;
  mimeType: string;
  fileName: string;
}
